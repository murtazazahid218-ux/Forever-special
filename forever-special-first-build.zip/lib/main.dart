import 'package:flutter/material.dart';

void main() => runApp(const ForeverSpecialApp());

const bg = Color(0xFF100B1D);
const panel = Color(0xFF211632);
const purple = Color(0xFF9B5CFF);
const pink = Color(0xFFFF69B4);

class ForeverSpecialApp extends StatelessWidget {
  const ForeverSpecialApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Forever Special',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const HomeDashboard(),
    );
  }
}

class HomeDashboard extends StatefulWidget {
  const HomeDashboard({super.key});
  @override
  State<HomeDashboard> createState() => _HomeDashboardState();
}

class _HomeDashboardState extends State<HomeDashboard> {
  int tab = 0;
  final pages = const ['Home', 'Your Songs', 'Favorites', 'Wishes', 'Downloads'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(index: tab, children: [
          _home(),
          const SimplePage(title: 'Your Songs', subtitle: 'Your shared music library'),
          const SimplePage(title: 'My Favorites', subtitle: 'Songs you have saved'),
          const SimplePage(title: 'Birthday Wishes', subtitle: 'Little messages, big feelings'),
          const SimplePage(title: 'Downloads', subtitle: 'Your offline music'),
        ]),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF1A1227),
        indicatorColor: purple.withOpacity(.25),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.library_music_rounded), label: 'Songs'),
          NavigationDestination(icon: Icon(Icons.favorite_rounded), label: 'Favorites'),
          NavigationDestination(icon: Icon(Icons.mail_rounded), label: 'Wishes'),
          NavigationDestination(icon: Icon(Icons.download_rounded), label: 'Downloads'),
        ],
      ),
    );
  }

  Widget _home() => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('FOREVER SPECIAL', style: TextStyle(letterSpacing: 2.2, color: pink, fontSize: 11, fontWeight: FontWeight.bold)),
          SizedBox(height: 5),
          Text('Your little music world ♡', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
        ])),
        CircleAvatar(backgroundColor: panel, child: Icon(Icons.person_outline, color: pink)),
      ]),
      const SizedBox(height: 24),
      Container(
        width: double.infinity, padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: const LinearGradient(colors: [Color(0xFF6F35B5), Color(0xFFB34891)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.favorite, size: 28),
          SizedBox(height: 18),
          Text('A world made of music', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          SizedBox(height: 6),
          Text('Songs, wishes and memories — all in one place.'),
          SizedBox(height: 18),
          Text('DISCOVER YOUR MUSIC  →', style: TextStyle(fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.bold)),
        ]),
      ),
      const SizedBox(height: 26),
      _heading('Your music', 'See all', () => setState(() => tab = 1)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _tile(Icons.library_music, 'Your Songs', 'Shared library', () => setState(() => tab = 1))),
        const SizedBox(width: 12),
        Expanded(child: _tile(Icons.favorite, 'Favorites', 'Your loved songs', () => setState(() => tab = 2))),
      ]),
      const SizedBox(height: 24),
      _heading('Made for you', 'Explore', () => setState(() => tab = 3)),
      const SizedBox(height: 12),
      _tile(Icons.mail_outline, 'Birthday Wishes', 'Messages to make you smile', () => setState(() => tab = 3), wide: true),
      const SizedBox(height: 12),
      _tile(Icons.cloud_upload_outlined, 'Add a song', 'Share music with everyone', () => _notice('Song uploads will be enabled after cloud setup.'), wide: true),
      const SizedBox(height: 24),
      const Text('Made with ♡ for someone special', style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );

  Widget _heading(String title, String action, VoidCallback onTap) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      TextButton(onPressed: onTap, child: Text(action, style: const TextStyle(color: pink))),
    ],
  );

  Widget _tile(IconData icon, String title, String subtitle, VoidCallback onTap, {bool wide = false}) =>
    InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: Container(
      width: wide ? double.infinity : null,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(.06))),
      child: Row(children: [
        Container(width: 42, height: 42, decoration: BoxDecoration(color: purple.withOpacity(.18), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: pink)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ])),
        const Icon(Icons.chevron_right, color: Colors.white38),
      ]),
    ));

  void _notice(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

class SimplePage extends StatelessWidget {
  final String title, subtitle;
  const SimplePage({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(28),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.auto_awesome, size: 48, color: pink),
      const SizedBox(height: 16),
      Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text(subtitle, style: const TextStyle(color: Colors.white60)),
      const SizedBox(height: 20),
      const Text('This section is being built.', style: TextStyle(color: Colors.white38)),
    ]),
  ));
}
